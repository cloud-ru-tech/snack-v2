# Figma Variables

Пакет дизайн-токенов (Figma Variables) для SberCloud UI. Исходные токены собираются в CSS, SCSS и TypeScript с помощью [@sbercloud/ft-tokens-builder](https://www.npmjs.com/package/@sbercloud/ft-tokens-builder).

## Структура токенов

Токены лежат в каталоге `tokens/` и объединяются в порядке, заданном в `$metadata.json`:

| Группа         | Описание                                                  |
| -------------- | --------------------------------------------------------- |
| `01_primitive` | Примитивные значения (цвета, отступы, типографика)        |
| `02_adaptive`  | Адаптивность (desktop, mobile)                            |
| `03_brand`     | Бренды (brandA, brandB)                                   |
| `04_theme`     | Темы (light, dark)                                        |
| `05_language`  | Языковые токены (en, ru) — исключены из сборки по конфигу |
| `06_acrylic`   | Эффект акрила (yes, no)                                   |
| `99_styles`    | Стили (gradient, typography, effect)                      |
| Компоненты     | Токены по компонентам (button, card, field и др.)         |

## Сборка

Сборка выполняется через [@sbercloud/ft-tokens-builder](https://www.npmjs.com/package/@sbercloud/ft-tokens-builder): читаются JSON-токены из `tokens/`, на выходе — CSS, SCSS и TypeScript в каталоге `build/`. Все файлы в `build/` **автогенерируются**, вручную их не редактируют.

```bash
# Установка зависимостей
pnpm deps

# Сборка токенов (CSS, SCSS, TS в ./build)
pnpm build:tokens

# Полная пересборка: очистка логов и build + сборка
pnpm build:all
```

### Конфигурация

Файл `tokens-builder.config.json`:

| Параметр                  | Значение                | Описание                                                        |
| ------------------------- | ----------------------- | --------------------------------------------------------------- |
| **input**                 | `./tokens`              | Каталог с исходными токенами                                    |
| **output**                | `./build`               | Каталог артефактов сборки                                       |
| **formats**               | `["css", "scss", "ts"]` | Форматы вывода                                                  |
| **excludeGroups**         | `["05_language"]`       | Группы токенов, не попадающие в сборку                          |
| **cssClassPrefix**        | `sn`                    | Префикс CSS-класса и переменных (`.sn-base-styles`, `--sn-...`) |
| **cssModules**            | `false`                 | Обычные CSS-файлы, без модулей                                  |
| **scssModules**           | `true`                  | SCSS в виде модулей (`.module.scss`)                            |
| **includeFallbackValues** | `true`                  | В TS/SCSS переменные с fallback: `var(--sn-..., #hex)`          |
| **validate**              | `strict`                | Строгая валидация токенов                                       |
| **logFile**               | `./logs/build.log`      | Файл лога сборки                                                |

---

## Результат сборки (структура `build/`)

### `build/css/`

Обычные CSS-файлы с переменными в классе `.sn-base-styles` (префикс `--sn-...`).

| Каталог / файл  | Содержимое                                                                 |
| --------------- | -------------------------------------------------------------------------- |
| **tokens.css**  | Сводный файл: импорт всех остальных CSS (база, темы, бренды, компоненты)   |
| **base/**       | Базовые примитивы (`base.css`)                                             |
| **adaptive/**   | Адаптивные токены: `desktop.css`, `mobile.css`                             |
| **brand/**      | Бренды: `brandA.css`, `brandB.css`                                         |
| **theme/**      | Темы: `light.css`, `dark.css`                                              |
| **acrylic/**    | Акрил: `yes.css`, `no.css`                                                 |
| **styles/**     | Стили: `effect.css`, `gradient.css`, `typography.css`, `styles.css`        |
| **components/** | По одному файлу на компонент: `button.css`, `card.css`, `field.css` и т.д. |

Использование: подключить `tokens.css` или нужные части (base + theme + brand + компоненты).


### `build/scss/`

SCSS в формате модулей; переменные с fallback через `var(--sn-..., #{st.$sn-...})`.

| Каталог / файл                | Содержимое                                                                                                                        |
| ----------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| **styles/styles.module.scss** | Базовый модуль: примитивы, адаптив, бренд, тема, стили; функции `simple-var`, `getValidKeys` для доступа к токенам                |
| **components/\*.module.scss** | Модули компонентов (например, `button.module.scss`): `@forward '../styles/styles.module'`, SCSS-переменные с `var(..., fallback)` |

Использование: подключать нужные модули (`@use '@sbecloud/figma-variables/build/scss/components/button.module'`) или базовый `styles.module.scss`.

### `build/ts/`

TypeScript/JS: один объект с токенами в виде строк `var(--sn-..., #fallback)`.

| Файл            | Содержимое                                                                                                                   |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| **styles.js**   | ESM/CommonJS: экспорт `themeVars` — вложенный объект по путям токенов (например, `themeVars.sn.primitive.color.brandA['5']`) |
| **styles.d.ts** | Типы для `themeVars`                                                                                                         |

Точки входа пакета (из `package.json`):

- **main**: `./build/ts/styles-theme-variables.js`
- **types**: `./build/ts/styles-theme-variables.d.ts`

Использование: импорт `themeVars` из пакета для подстановки значений в JS/TS (например, в инлайн-стилях или при генерации разметки).

## Скрипты

| Скрипт         | Действие                                        |
| -------------- | ----------------------------------------------- |
| `clean:build`  | Удалить каталог `build`                         |
| `clean:logs`   | Удалить каталог `logs`                          |
| `clean:all`    | Очистить логи и build                           |
| `build:tokens` | Запуск tokens-builder                           |
| `build:all`    | Очистка + сборка токенов                        |
| `deps`         | Установка зависимостей                          |
| `reinstall`    | Удаление node_modules и lockfile, переустановка |

## Лицензия

Apache-2.0
