# Figma Tokens Plugin — SCSS из переменных Figma

Плагин для Figma **Dev Mode** (режим Inspect): по выбранному слою или компоненту генерирует готовые блоки SCSS под пакет `@sbercloud/figma-variables`. Вместо сырого CSS с `var(--sn-...)` плагин выдаёт импорты, переменные, заготовки циклов и стили выделенного блока с вызовами миксинов и ссылками на токены.

---

## Что делает плагин

1. **Читает переменные** выбранного слоя из Figma (`boundVariables` и/или `getCSSAsync()`).
2. **Определяет компонент** (alert, button, toggles и т.д.) по корню инстанса или по именам переменных.
3. **Собирает переменные со страницы**: находит до 20 инстансов того же компонента на текущей странице и объединяет уникальные варианты (size, status, color и т.п.) для списков в блоках 1 и 2.
4. **Строит четыре блока**:
   - **Блок 1** — импорты (`@use` base + компонент) и переменные (`$size`, `$status`, `$typography` и т.д.), собранные со страницы.
   - **Блок 2** — заготовка класса компонента с циклами `@each` по anatomy (size/shape) и theme (color, appearance и т.д.); в месте стилей выделенного слоя — комментарий «см. блок 3».
   - **Блок 3** — только стили **выделенного** слоя: вызовы `@include base.composite-var(...)` по путям анатомии и обычные свойства (display, width и т.п.). Свойства, которые уже даёт composite-var (padding, gap, height по тому же пути), в блок 3 не попадают.
   - **Блок 4** — сырой CSS выделенного слоя (как из Inspect), для сверки.
5. **Копирование**: у каждого блока — своя кнопка Copy; внизу — Copy full SCSS (всё одним куском).

Имена переменных и ключи карт используются **как в пакете и Figma** (camelCase и т.д.), без приведения к snake-case.

---

## Установка и запуск

1. Установите зависимости: `pnpm install`
2. Соберите плагин: `pnpm run build`  
   В `dist/` появятся `code.js`, `manifest.json`, `ui.html`. Перед сборкой запускаются генерация карт из `@sbercloud/figma-variables`, сборка кода плагина (esbuild) и сборка UI (Vite → один инлайновый `ui.html`).
3. В Figma: **Resources** → **Plugins** → **Development** → **Import plugin from manifest…** → укажите папку **dist**.
4. Включите **Dev Mode** и откройте панель **Inspect**.
5. В Inspect выберите плагин «SCSS Mixins (figma-variables)».
6. Выберите слой или компонент с привязанными переменными (например, из [Snack Ui Kit variables](https://www.figma.com/design/aNPU3MHwRJiEwbk5F82zux/)) — в плагине появятся четыре блока и кнопки копирования.

---

## Как устроен код

### Общий поток

1. При смене выделения вызывается `sendSelectionToUI()` в `src/plugin/code.ts`.
2. Для выбранных узлов собираются данные: переменные (по `boundVariables` и/или из CSS), миксины и «простые» переменные, полный CSS слоя.
3. Определяется компонент (по корню инстанса или по первой переменной), опции вариантов (size, status и т.д.) и путь от корня инстанса до выделенного узла.
4. Переменные дополнительно собираются **со страницы** (до 20 инстансов того же компонента) и объединяются с переменными выделения для блоков 1 и 2.
5. Стили выделенного слоя (блок 3) фильтруются: свойства, чьи переменные лежат «внутри» пути уже покрытого вызовом `composite-var`, убираются (по префиксу пути, без дублирования).
6. `generateFullScss()` в `src/generators/generateFullScss.ts` формирует три текстовых блока (и полный SCSS); в UI отображаются четыре блока (1–3 + Raw CSS).

### Основные файлы

| Файл | Назначение |
|------|------------|
| **src/plugin/code.ts** | Точка входа плагина. Сбор переменных и CSS с узлов, вызов маппинга в миксины, агрегация со страницы, фильтр «внутри composite-var», вызов генератора SCSS, отправка результата в UI. |
| **src/core/variableToMixin.ts** | Парсинг имён переменных (`sn-<component>-anatomy-size-...` или `sn/component/...`), группировка по блоку анатомии, сборка строки миксина `@include base.composite-var(module.$map, 'anatomy', 'size', $size, ...)`. Использует `ANATOMY_SEGMENT_NAMES_BY_COMPONENT` и `COMPONENT_MAP` из сгенерированных карт. |
| **src/core/types.ts** | Общие типы (LayerInfo, MixinSuggestion, SimpleVarSuggestion, ComponentSetupVar и т.д.). |
| **src/generators/generateFullScss.ts** | Генерация трёх блоков SCSS: импорты и переменные (блок 1), класс с циклами по size/shape и theme (блок 2), стили только выделенного слоя (блок 3). Поддерживает как вложенную анатомию (anatomy.size), так и прямую (anatomy.s/m/l, например block). Использует данные из `src/generated/tokenMaps.ts`. |
| **src/generated/tokenMaps.ts** | Автогенерируемый файл (не редактировать вручную). Содержит `COMPONENT_MAP` (из списка файлов в пакете), anatomy tails, anatomy direct keys (block-style), segment names, typography by size, theme vars и CSS_VAR_TO_JS_PATH. |
| **scripts/generate-token-maps.ts** | Читает `@sbercloud/figma-variables/build/scss` и `build/ts`, извлекает карты и список компонентов, пишет `src/generated/tokenMaps.ts`. |
| **scripts/build-plugin.ts** | Запускает `generate-maps`, esbuild (плагин → `dist/code.js`), Vite (UI → `dist/ui.html`), копирует `manifest.json` в `dist/`. |
| **vite.config.ts** | Сборка UI: React + SCSS + токены → один `dist/ui.html` с инлайновыми JS и CSS. Production: минификация; development (watch): без минификации, с sourcemaps. |
| **ui/ui.html** | Точка входа UI для Vite; подключает `ui/src/main.tsx`. |
| **ui/src/main.tsx** | Монтирование React: ErrorBoundary → App, подключение tokens.css и ui.scss. |
| **ui/src/App.tsx** | Основной экран: хук `usePluginMessages`, блоки кода (CodeBlock), кнопки Copy и Copy full SCSS. |
| **ui/src/components/** | CodeBlock (блок кода + Copy), ErrorBoundary (ловля ошибок + кнопка «Close & run plugin again»). |
| **ui/src/hooks/usePluginMessages.ts** | Подписка на `postMessage` от плагина, возвращает `{ payload, isLoading }`. |
| **ui/src/types/** | Тип `ResultPayload` (payload из плагина). |
| **ui/src/utils/copyToClipboard.ts** | Копирование текста в буфер обмена. |

### Детали логики в plugin/code.ts

- **Переменные с узла**: из `boundVariables` достаются id переменных, по ним запрашиваются имена (`getVariableByIdAsync`); если имён нет — из `getCSSAsync()` вытаскиваются имена из `var(--...)`.
- **Миксины и простые переменные**: список имён `sn-*` разбивается на anatomy-переменные (дают вызовы `composite-var`) и остальные (дают `base.$sn-...` в стилях). Группировка по пути анатомии и склейка сегментов — в `src/core/variableToMixin.ts`.
- **Агрегация со страницы**: для определённого компонента по странице ищутся инстансы того же типа (`getMainComponentAsync`), с них рекурсивно собираются id переменных, по id — имена; результат объединяется с переменными выделения для блоков 1 и 2.
- **Фильтр «внутри composite-var»**: по каждому миксину выделенного слоя строится префикс пути (например `sn-alert-anatomy-size-m-container`). Строка стиля отфильтровывается, если её значение — ссылка `base.$...`, и имя переменной совпадает с префиксом или начинается с `префикс-`. Так из блока 3 убираются свойства, уже задаваемые соответствующим `@include base.composite-var(...)`.
- **Полный CSS → SCSS**: в `fullCSSToScssLines` каждый `var(--sn-...)` подменяется на `base.$sn-...` (или на значение из `CSS_VAR_TO_JS_PATH` для theme); имена выводятся как в пакете, без преобразований.

### Зависимость от пакета

Плагин опирается на `@sbercloud/figma-variables`: список компонентов и карты (anatomy, typography, theme) генерируются из `build/scss` и `build/ts` пакета. Имена переменных и ключи карт совпадают с Figma (camelCase и т.д.). При обновлении пакета достаточно пересобрать плагин (`pnpm run build`), чтобы перегенерировать карты и пересобрать код.

---

## Сборка и скрипты

```bash
pnpm install
pnpm run build          # Полная сборка: generate-maps + esbuild (плагин) + Vite (UI, production) → dist/
pnpm run build:plugin   # То же, что build
pnpm run build:ui      # Только UI: Vite в режиме production (минификация, оптимизации)
pnpm run build:watch   # UI в режиме development: Vite --watch, без минификации, с sourcemaps (удобно при правках UI)
pnpm run build:lib      # Собрать npm-пакет @sbercloud/figma-selected-block в dist/lib/ (tsc → CJS + .d.ts)
pnpm run generate-maps  # Только генерация src/generated/tokenMaps.ts
pnpm run selected-block # Запустить CLI локально (tsx) — см. раздел «CLI для агента» ниже
pnpm run typecheck     # tsc --noEmit
```

---

## CLI для агента (Figma MCP)

Плагин публикуется и как npm-пакет `@sbercloud/figma-selected-block` — **библиотека + CLI**, повторяющие «Блок 3 (Стили выделенного блока)» без Figma. Используется AI-агентом в связке с Figma MCP: агент через MCP получает CSS выделенной ноды и передаёт его сюда.

Ограничение: блоки 1 и 2 (импорты + циклы) не генерируются — они требуют обхода страницы Figma, чего MCP не даёт.

### Установка как зависимости

```bash
pnpm add -D @sbercloud/figma-selected-block
```

Пакет self-contained: `src/generated/tokenMaps.ts` инлайнится в `dist/lib/`, `@sbercloud/figma-variables` в рантайме не нужен.

### CLI

```bash
# 1) По ссылке / ref из Figma REST (нужен FIGMA_TOKEN)
export FIGMA_TOKEN=figd_...
npx figma-selected-block --url "https://www.figma.com/design/<fileKey>/Name?node-id=12-345"
npx figma-selected-block --node-ref "<fileKey>/12:345" --format json

# 2) CSS из файла (сценарий с Figma MCP / плагином)
npx figma-selected-block --css-file selected.css --component alert

# 3) CSS строкой
npx figma-selected-block --css "padding: var(--sn-alert-anatomy-size-m-container-padding-top) 4px;"

# 4) JSON по stdin (как агент)
echo '{"css":"...","componentHint":"alert"}' | npx figma-selected-block --format json
```

Флаги: `--url` / `--node-ref`, `--token` (или `FIGMA_TOKEN` env), `--css-file`, `--css`, `--component` (хинт), `--format scss|json` (по умолчанию `scss`).
Exit codes: `0` — ок, `1` — парс-/сеть-ошибка, `2` — не удалось определить компонент.

**Режим Figma REST** (`--url` / `--node-ref`):

- Если у токена есть scope `file_variables:read` — имена переменных резолвятся напрямую через `/v1/files/:key/variables/local`.
- Если scope'а нет (Figma возвращает 403) — CLI падает в **эвристический режим**: имена реконструируются из anatomy-карт в `src/generated/tokenMaps.ts` по схеме `sn-{component}-anatomy-{axis}-{value}-{pathSegments}-{leaf}`. Работает, когда URL указывает на `COMPONENT` / `COMPONENT_SET` / `INSTANCE` (component name берётся из `componentSets[..].name` в REST response), а для вложенных `FRAME` нужно явно указать `--component <name> --variant size=xs`.
- Синтезируются: paddings (+ агрегаты `paddingHorizontal`/`paddingVertical`), `gap` (itemSpacing), border-radius (uniform + 4 угла), border-width (uniform + индивидуальные), min/max width/height, display/flex-direction, первый solid fill. **Не покрыты** тени, цвета обводок, типографика, theme-цвета (`sn-theme-*`) — для них используйте путь через Figma MCP / плагин (`getCSSAsync()`).

Пример (без scope `file_variables:read`):

```bash
# Корень варианта: component и variant берутся из имени ноды ("size=xs, appearance=neutral")
npx figma-selected-block --url "https://www.figma.com/design/<key>/X?node-id=3862-10234"

# Вложенный фрейм: нужен --component и --variant
npx figma-selected-block --url "https://www.figma.com/design/<key>/X?node-id=3874-1603" \
  --component tag --variant size=m
```

### Библиотека

```ts
import {
  generateSelectedBlock,
  fetchSelectedBlockFromFigma,
} from "@sbercloud/figma-selected-block";

// Путь 1: CSS уже есть (например, от Figma MCP)
const { scss } = generateSelectedBlock({
  css: "padding: var(--sn-alert-anatomy-size-m-container-padding-top) 4px;",
});

// Путь 2: только ссылка / node-id — REST-клиент получит ноду и сам соберёт CSS
const result = await fetchSelectedBlockFromFigma(
  "https://www.figma.com/design/<fileKey>/Name?node-id=12-345",
  { token: process.env.FIGMA_TOKEN },
);
console.log(result.scss, result.synthesizedCss);
```

### Локальная разработка

```bash
pnpm run selected-block -- --css-file fixture.css
# или напрямую tsx (стдин доступен):
echo 'padding: var(--sn-alert-...);' | pnpm exec tsx scripts/generate-selected-block.ts
```

- **Production** (`build`, `build:ui`): UI собирается с минификацией (esbuild), tree-shaking, без sourcemaps.
- **Development** (`build:watch`): UI без минификации, с sourcemaps; при изменении файлов в `ui/` пересборка автоматическая.

Подключение в Figma: после `pnpm run build` указать папку **dist** в «Import plugin from manifest».

### Релизы (master)

На ветке **master** при пуше коммитов в формате [Conventional Commits](https://www.conventionalcommits.org/) (например `feat: ...`, `fix: ...`) пайплайн:

1. Собирает проект.
2. Запускает **semantic-release**: определяет новую версию, обновляет `package.json` и `manifest.json`, генерирует CHANGELOG, коммитит и пушит тег вида `v1.0.0`.
3. Создаёт **GitLab Release** с этим тегом и прикрепляет архив плагина `figma-tokens-plugin.tar.gz`.

В CI/CD должна быть переменная **GITLAB_TOKEN** (scope: api) для пуша коммита/тега и создания релиза. Версию вручную в манифесте менять не нужно — её выставляет semantic-release.

---

## Публикация в организацию Figma

Figma не предоставляет REST API для публикации плагинов — загрузка делается вручную через приложение Figma.

**Из CI (master):**

1. После успешного пайплайна откройте **Releases** в GitLab и скачайте архив плагина из нужного релиза (тег `v1.0.0` и т.д.).
2. Распакуйте архив в любую папку (внутри будут `code.js`, `manifest.json`, `ui.html`).
3. В Figma: **Resources** → **Plugins** → **Publish** (или **In development** → выберите плагин → **Publish**).
4. Укажите папку с распакованным плагином (или импортируйте из manifest).
5. На шаге «Add the final details» в поле **Publish to** выберите **вашу организацию** — плагин будет доступен только внутри организации.

Подробнее: [Create private plugins for an organization](https://help.figma.com/hc/en-us/articles/4404228629655-Create-private-organization-plugins).

---

## Структура проекта

```
figma-tokens-plugin/
├── manifest.json         # манифест плагина (Dev Mode, inspect)
├── package.json
├── vite.config.ts        # конфиг Vite для UI (production / development)
├── src/
│   ├── plugin/
│   │   └── code.ts       # точка входа плагина
│   ├── core/
│   │   ├── types.ts      # общие типы
│   │   └── variableToMixin.ts  # парсинг переменных, миксины
│   ├── generators/
│   │   └── generateFullScss.ts  # генерация блоков 1–3 и полного SCSS
│   └── generated/
│       └── tokenMaps.ts  # сгенерированные карты (не править вручную)
├── scripts/
│   ├── generate-token-maps.ts  # генерация карт из @sbercloud/figma-variables
│   └── build-plugin.ts         # generate-maps + esbuild + Vite (UI) + копирование в dist/
├── ui/
│   ├── ui.html           # точка входа для Vite, подключает src/main.tsx
│   ├── ui.scss           # глобальные стили (токены, блоки, Error Boundary)
│   └── src/
│       ├── main.tsx      # монтирование React (ErrorBoundary → App)
│       ├── App.tsx       # основной экран (блоки кода, Copy)
│       ├── types/        # ResultPayload и др.
│       ├── hooks/        # usePluginMessages
│       ├── components/   # CodeBlock, ErrorBoundary
│       └── utils/        # copyToClipboard
├── tokens/               # референсные токены (block, calendar, …)
└── dist/                 # артефакты сборки (code.js, manifest.json, ui.html)
```

---

## Ограничения

- Работает только в **Dev Mode** и в контексте **Inspect** (только чтение).
- Учитываются переменные с именами вида `sn-*` или `sn/*` (формат пакета/Figma).
- Список компонентов выводится из пакета `@sbercloud/figma-variables` при сборке; новые компоненты в пакете подхватываются автоматически после `pnpm run build`.
- Для корректной работы нужна актуальная версия `@sbercloud/figma-variables` с именами переменных, совпадающими с Figma.
